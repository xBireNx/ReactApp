import React from 'react'
import './Registration.css'

export default function Registration() {
    return (
        <>
            <div className="form-box">
                <center>
                    <h1>Registration</h1>
                    <form>
                    <input type="text" name='firstname' placeholder='First Name' />
                    <br/><input type="text" name='lastname' placeholder='Last Name' />
                    <br/><input type="text" name='email' placeholder='Email' />
                    <br/><input type="password" name='password' placeholder='Password' />
                    <br/><input type="password" name='cpassword' placeholder='Confirm Password' />
                    <br/><button type='submit'>Submit</button>
                    </form>
                </center>
            </div>
        </>
    )
}
