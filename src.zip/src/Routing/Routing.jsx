import React from 'react'
import Navii from '../Layout/Navbar/Navii'
import { Switch , BrowserRouter , Route } from 'react-router-dom'
import Registration from '../Auth/Registration/Registration'
import ProductCategory from '../Product/ProductCategory/ProductCategory'
import ProductList from '../Product/ProductList/ProductList'
import ProductDetails from '../Product/ProductDetails/ProductDetails'
import Cart from '../Product/Cart/Cart'
export default function Routing() {
    return (
        <div>
            <BrowserRouter>
                <Navii></Navii>
                <Switch>
                    <Route exact path='/Registration' component={Registration}/>
                    <Route exact path='/Category' component={ProductCategory}/>
                    <Route exact path='/ProductList/:cname' component={ProductList}/>
                    <Route exact path='/ProductDetails/:pidd' component={ProductDetails}/>
                    <Route exact path='/Cart' component={Cart}/>
                </Switch>
            </BrowserRouter>
        </div>
    )
}
