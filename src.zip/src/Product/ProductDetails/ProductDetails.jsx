import React, { useEffect } from "react";
import {Link, useHistory} from 'react-router-dom'
import { useDispatch, useSelector } from "react-redux";
import { productdetails } from "../../Action/ProductAction";
import './ProductDetails.css';
import {CartDet} from '../../Action/CartAction'


export default function ProductDetails({ match }) {
    const history = useHistory()
    const pdetails = match.params.pidd;
    console.log(pdetails);
    const DispatchMethod = useDispatch();
    const ProductCategoryww = useSelector((state) => state.productData);
    console.log(ProductCategoryww);
    const ProductDet = ProductCategoryww.ProductDetails;
    useEffect(() => {
      DispatchMethod(productdetails(pdetails));
    }, [DispatchMethod]);

    function AddToCart(ProductDet){
        DispatchMethod(CartDet(ProductDet));
        history.push('/Cart')
    }

    return (
        <div>
            	<div className="container">
		<div className="card">
			<div className="container-fliud">
				<div className="wrapper row">
					<div className="preview col-md-6">
						
						<div className="preview-pic tab-content">
						  <div className="tab-pane active" id="pic-1"><img src={ProductDet.image} /></div>
						</div>
					</div>
					<div className="details col-md-6">
						<h3 className="product-title">{ProductDet.title}</h3>
						<div className="rating">
							<span className="review-no">{ProductDet.category}</span>
						</div>
						<p className="product-description">{ProductDet.description}</p>
						<h4 className="price">current price: <span>${ProductDet.price}</span></h4>
						<div className="action">
							<button className="add-to-cart btn btn-default" onClick={()=>AddToCart(ProductDet)} type="button">add to cart</button>
							<button className="like btn btn-default" type="button"><span className="fa fa-heart"></span></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
        </div>
      );
    }