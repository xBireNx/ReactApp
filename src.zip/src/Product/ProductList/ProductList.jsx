import React, { useEffect } from "react";
import {Link} from 'react-router-dom'
import { useDispatch, useSelector } from "react-redux";
import { subcatagory } from "../../Action/ProductAction";
import { Card,Container,Row } from 'react-bootstrap';

export default function ProductList({ match }) {
  const cdetails = match.params.cname;
  console.log(cdetails);
  const DispatchMethod = useDispatch();
  const ProductCategoryw = useSelector((state) => state.productData);
  console.log(ProductCategoryw);
  
  useEffect(() => {
    DispatchMethod(subcatagory(cdetails));
  }, [DispatchMethod]);
  return (
    <div>
        <Container>
            <Row>
      {ProductCategoryw.Specific_CategoryData.map((e) => (
        <Card key={e.id}>
          <Card.Img variant="top" src="holder.js/100px180" />
          <Card.Body>
            <Card.Title><Link to={`/ProductDetails/${e.id}`}>{e.title}</Link></Card.Title>
          </Card.Body>
        </Card>
      ))}
      </Row>
      </Container>

      {/* {
          ProductCategoryw.Specific_CategoryData.map((e) => (
              <div key={e.id}>{e.title}</div>
          ))
      } */}

    </div>
  );
}