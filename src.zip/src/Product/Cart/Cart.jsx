import React from 'react'
import {useSelector} from 'react-redux';



export default function Cart() {

    const CartDetails = useSelector((state) => state.cartData)
    console.log(CartDetails);
    return (
        <div>
            {/* {CartDetails.title} */}
            hhh
        </div>
    )
}
