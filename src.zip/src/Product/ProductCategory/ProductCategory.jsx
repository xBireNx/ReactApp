import React, {useState , useEffect} from 'react'
import {Link} from 'react-router-dom'
import {useDispatch , useSelector} from 'react-redux';
import {ProductCategories} from '../../Action/ProductAction'

export default function ProductCategory() {
    const DispatchMethod = useDispatch()
    const ProductCategoryss = useSelector((state) => state.productData)
    console.log(ProductCategoryss);
    
    useEffect(() =>{
        DispatchMethod( ProductCategories() );
    }, [DispatchMethod])

    return (
         <div>
             {
             ProductCategoryss.AllCate.map((e)=>(
                 <div key={e}><Link to={`/ProductList/${e}`}>{e}</Link></div>
             ))
         }
        </div>
    )
}
