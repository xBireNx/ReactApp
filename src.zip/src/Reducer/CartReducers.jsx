import {CartConst} from '../Action/ActionConst'

const initial = {
    CartDetails: [],
    Error: null,
    Message: ""
}

const CartReducers = (state=initial, action) => {

    switch(action.type){
        case `${CartConst.CART_POST}_REQUEST` :
            return state = {
                ...state
            }

        case `${CartConst.CART_POST}_SUCCESS` :
            // var Cartt = []
            // Cartt.push(action)
            return state = {
                ...state,
                CartDetails: [...action.payload.cartdata],
                Message: action.payload.message
            }

        case `${CartConst.CART_POST}_FAIL` :
            return state = {
                ...state,
                Error: action.payload.message
            }

        default: return state
    }
}
export default CartReducers